import type { ChatInputCommandInteraction, SlashCommandBuilder} from 'discord.js';

export interface Command {
    data: SlashCommandBuilder;
    execute: (interaction: ChatInputCommandInteraction) =>  Promise<void>;
    cooldown?: number;
}
